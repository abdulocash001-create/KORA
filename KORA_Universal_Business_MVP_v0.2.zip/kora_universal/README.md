# KORA Universal Business App — MVP v0.2

KORA is designed as one simple business app for:
- Phone shops
- Supermarkets
- Pharmacies
- Restaurants
- Boutiques
- Electronics stores
- Spare-parts businesses
- Other businesses

## Included

- Business-type setup
- Business-specific categories
- Universal product/stock records
- SKU + barcode fields
- Supplier field
- Unit selection (piece, pack, box, bag, kg, litre, plate, etc.)
- Brand and variant fields
- Phone/electronics serial/IMEI tracking flag
- Pharmacy expiry + batch tracking
- Restaurant stock/menu-friendly mode
- Sales + payment method
- Transaction history
- Low-stock alerts
- Expiry & batch view
- Reports
- Local offline persistence

## Run

flutter pub get
flutter run

## Production modules still to build

Authentication, cloud database/sync, real staff permissions, barcode/QR scanning,
IMEI/serial records, pharmacy safety controls, restaurant recipes/ingredients,
customers, suppliers, expenses, profit accounting, receipts/printing, backups,
multi-branch, audit logs, notifications, subscription/billing, admin panel,
security hardening and Play Store release configuration.
