import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const blue = Color(0xFF0869E8);
const darkBlue = Color(0xFF082B63);
const green = Color(0xFF16A36A);
const red = Color(0xFFE53935);
const bg = Color(0xFFF6F8FC);

const businessTypes = [
  'Phone Shop', 'Supermarket', 'Pharmacy', 'Restaurant',
  'Boutique', 'Electronics', 'Spare Parts', 'Other'
];

final Map<String, List<String>> categories = {
  'Phone Shop': ['Phones', 'Tablets', 'Accessories', 'Chargers', 'SIM/Other'],
  'Supermarket': ['Food', 'Drinks', 'Household', 'Personal Care', 'Other'],
  'Pharmacy': ['Medicine', 'Supplements', 'Medical Items', 'Personal Care', 'Other'],
  'Restaurant': ['Food', 'Drinks', 'Snacks', 'Ingredients', 'Other'],
  'Boutique': ['Men', 'Women', 'Children', 'Shoes', 'Bags', 'Accessories'],
  'Electronics': ['TV', 'Audio', 'Computers', 'Cameras', 'Accessories', 'Other'],
  'Spare Parts': ['Cars', 'Motorcycles', 'Generators', 'Electrical', 'Tools', 'Other'],
  'Other': ['General', 'Other'],
};

String money(double n) {
  final s = n.round().toString();
  final b = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(',');
    b.write(s[i]);
  }
  return '₦$b';
}

class Product {
  String id, name, category, businessType, supplier, sku, unit;
  String barcode, brand, variant, notes, batchNumber, expiryDate;
  double buyingPrice, sellingPrice;
  int quantity, lowStockAt;
  bool trackExpiry, trackSerial;

  Product({
    required this.id, required this.name, required this.category,
    required this.businessType, required this.buyingPrice,
    required this.sellingPrice, required this.quantity,
    this.supplier='', this.sku='', this.unit='Piece', this.barcode='',
    this.brand='', this.variant='', this.notes='', this.batchNumber='',
    this.expiryDate='', this.lowStockAt=3, this.trackExpiry=false,
    this.trackSerial=false,
  });

  Map<String,dynamic> toJson()=> {
    'id':id,'name':name,'category':category,'businessType':businessType,
    'supplier':supplier,'sku':sku,'unit':unit,'barcode':barcode,
    'brand':brand,'variant':variant,'notes':notes,'batchNumber':batchNumber,
    'expiryDate':expiryDate,'buyingPrice':buyingPrice,'sellingPrice':sellingPrice,
    'quantity':quantity,'lowStockAt':lowStockAt,'trackExpiry':trackExpiry,
    'trackSerial':trackSerial
  };

  factory Product.fromJson(Map<String,dynamic> j)=>Product(
    id:j['id'], name:j['name'], category:j['category']??'Other',
    businessType:j['businessType']??'Other',
    supplier:j['supplier']??'',sku:j['sku']??'',unit:j['unit']??'Piece',
    barcode:j['barcode']??'',brand:j['brand']??'',variant:j['variant']??'',
    notes:j['notes']??'',batchNumber:j['batchNumber']??'',
    expiryDate:j['expiryDate']??'',
    buyingPrice:(j['buyingPrice'] as num).toDouble(),
    sellingPrice:(j['sellingPrice'] as num).toDouble(),
    quantity:j['quantity'],lowStockAt:j['lowStockAt']??3,
    trackExpiry:j['trackExpiry']??false,trackSerial:j['trackSerial']??false,
  );
}

class Sale {
  String id, productName, date, payment;
  int quantity;
  double amount;
  Sale({required this.id,required this.productName,required this.date,
    required this.quantity,required this.amount,this.payment='Cash'});
  Map<String,dynamic> toJson()=>{'id':id,'productName':productName,'date':date,
    'quantity':quantity,'amount':amount,'payment':payment};
  factory Sale.fromJson(Map<String,dynamic> j)=>Sale(
    id:j['id'],productName:j['productName'],date:j['date'],quantity:j['quantity'],
    amount:(j['amount'] as num).toDouble(),payment:j['payment']??'Cash');
}

class KoraStore extends ChangeNotifier {
  List<Product> products=[];
  List<Sale> sales=[];
  String businessType='Supermarket';
  String businessName='My Business';

  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    businessType=p.getString('businessType')??'Supermarket';
    businessName=p.getString('businessName')??'My Business';
    products=(p.getStringList('products')??[]).map((x)=>Product.fromJson(jsonDecode(x))).toList();
    sales=(p.getStringList('sales')??[]).map((x)=>Sale.fromJson(jsonDecode(x))).toList();
    if(products.isEmpty) seed();
  }

  void seed(){
    products=[
      Product(id:'1',name:'iPhone 13 Pro',category:'Phones',businessType:'Phone Shop',
        buyingPrice:430000,sellingPrice:460000,quantity:4,brand:'Apple',sku:'IP13-001',trackSerial:true),
      Product(id:'2',name:'Rice 50kg',category:'Food',businessType:'Supermarket',
        buyingPrice:25000,sellingPrice:28000,quantity:5,unit:'Bag',sku:'RICE50'),
      Product(id:'3',name:'Paracetamol 500mg',category:'Medicine',businessType:'Pharmacy',
        buyingPrice:700,sellingPrice:1000,quantity:12,unit:'Pack',batchNumber:'PCM-26',
        expiryDate:'2027-06',trackExpiry:true),
      Product(id:'4',name:'Men T-Shirt',category:'Men',businessType:'Boutique',
        buyingPrice:6000,sellingPrice:9000,quantity:8,variant:'L / Black',brand:'KORA Fashion'),
    ];
  }

  Future<void> save() async {
    final p=await SharedPreferences.getInstance();
    await p.setString('businessType',businessType);
    await p.setString('businessName',businessName);
    await p.setStringList('products',products.map((x)=>jsonEncode(x.toJson())).toList());
    await p.setStringList('sales',sales.map((x)=>jsonEncode(x.toJson())).toList());
    notifyListeners();
  }

  Future<void> add(Product x) async {products.add(x);await save();}
  Future<void> sell(Product p,int q,String payment) async {
    if(q<1||q>p.quantity)return;
    p.quantity-=q;
    sales.insert(0,Sale(id:DateTime.now().millisecondsSinceEpoch.toString(),
      productName:p.name,date:DateTime.now().toString(),quantity:q,
      amount:p.sellingPrice*q,payment:payment));
    await save();
  }

  double get stockValue=>products.fold(0,(a,p)=>a+p.buyingPrice*p.quantity);
  double get salesTotal=>sales.fold(0,(a,s)=>a+s.amount);
  int get itemsSold=>sales.fold(0,(a,s)=>a+s.quantity);
  double get profit=>sales.fold(0,(a,s){
    final p=products.where((x)=>x.name==s.productName).firstOrNull;
    return a+(p==null?0:(p.sellingPrice-p.buyingPrice)*s.quantity);
  });
  List<Product> get lowStock=>products.where((p)=>p.quantity<=p.lowStockAt).toList();
  List<Product> get expiring=>products.where((p)=>p.trackExpiry&&p.expiryDate.isNotEmpty).toList();
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store=KoraStore();
  await store.load();
  runApp(KoraApp(store));
}

class KoraApp extends StatelessWidget {
  final KoraStore store;
  const KoraApp(this.store,{super.key});
  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:store,builder:(_,__)=>MaterialApp(
      debugShowCheckedModeBanner:false,title:'KORA',
      theme:ThemeData(useMaterial3:true,scaffoldBackgroundColor:bg,
        colorScheme:ColorScheme.fromSeed(seedColor:blue)),
      home:Login(store),
    ));
}

class Login extends StatelessWidget {
  final KoraStore store;
  const Login(this.store,{super.key});
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Center(
    child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(children:[
      const SizedBox(height:45),
      Container(width:92,height:92,decoration:BoxDecoration(color:blue,borderRadius:BorderRadius.circular(28)),
        child:const Icon(Icons.inventory_2_rounded,color:Colors.white,size:48)),
      const SizedBox(height:15),
      const Text('KORA',style:TextStyle(fontSize:35,fontWeight:FontWeight.w900,color:darkBlue)),
      const Text('Track. Sell. Grow.',style:TextStyle(color:Colors.grey,fontWeight:FontWeight.w600)),
      const SizedBox(height:55),
      const Align(alignment:Alignment.centerLeft,child:Text('Welcome Back',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold))),
      const SizedBox(height:20),
      const TextField(decoration:InputDecoration(prefixIcon:Icon(Icons.person_outline),hintText:'Email or Phone Number')),
      const SizedBox(height:12),
      const TextField(obscureText:true,decoration:InputDecoration(prefixIcon:Icon(Icons.lock_outline),hintText:'Password')),
      const SizedBox(height:20),
      SizedBox(width:double.infinity,height:54,child:FilledButton(
        onPressed:()=>Navigator.pushReplacement(c,MaterialPageRoute(builder:(_)=>Shell(store))),
        child:const Text('Login'))),
      const SizedBox(height:12),
      OutlinedButton(onPressed:()=>showBusinessSetup(c,store),child:const Text('Create New Business')),
    ]))));
}

Future<void> showBusinessSetup(BuildContext c,KoraStore s) async {
  String type=s.businessType; final name=TextEditingController(text:s.businessName);
  await showDialog(context:c,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(
    title:const Text('Set up your business'),
    content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:name,decoration:const InputDecoration(labelText:'Business name')),
      const SizedBox(height:12),
      DropdownButtonFormField<String>(value:type,decoration:const InputDecoration(labelText:'Business type'),
        items:businessTypes.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
        onChanged:(v)=>set(()=>type=v!)),
    ])),
    actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),
      FilledButton(onPressed:()async{s.businessType=type;s.businessName=name.text.trim().isEmpty?'My Business':name.text.trim();
        await s.save();if(ctx.mounted)Navigator.pop(ctx);},child:const Text('Continue'))],
  )));
}

class Shell extends StatefulWidget {
  final KoraStore store; const Shell(this.store,{super.key});
  @override State<Shell> createState()=>_ShellState();
}
class _ShellState extends State<Shell>{
  int i=0;
  @override Widget build(BuildContext c){
    final pages=[Dashboard(store:widget.store),StockPage(widget.store),History(widget.store),Profile(widget.store)];
    return Scaffold(body:pages[i],bottomNavigationBar:NavigationBar(selectedIndex:i,
      onDestinationSelected:(x)=>setState(()=>i=x),destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.inventory_2_outlined),selectedIcon:Icon(Icons.inventory_2),label:'Stock'),
        NavigationDestination(icon:Icon(Icons.history),label:'History'),
        NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile'),
      ]));
  }
}

class Dashboard extends StatelessWidget{
  final KoraStore store; const Dashboard({required this.store,super.key});
  @override Widget build(BuildContext c)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[
    Row(children:[const CircleAvatar(backgroundColor:blue,child:Icon(Icons.store,color:Colors.white)),
      const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Good Morning',style:TextStyle(color:Colors.grey)),
        Text(store.businessName,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))])),
      IconButton(onPressed:(){},icon:const Icon(Icons.notifications_none))]),
    const SizedBox(height:15),
    Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(
      gradient:const LinearGradient(colors:[darkBlue,blue]),borderRadius:BorderRadius.circular(22)),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('Total Stock Value',style:TextStyle(color:Colors.white70)),
        Text(money(store.stockValue),style:const TextStyle(color:Colors.white,fontSize:28,fontWeight:FontWeight.bold)),
        Text(store.businessType,style:const TextStyle(color:Colors.white70))])),
    const SizedBox(height:14),
    GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
      mainAxisSpacing:10,crossAxisSpacing:10,childAspectRatio:1.8,children:[
      stat('Products','${store.products.length}',Icons.inventory_2),
      stat('Items Sold','${store.itemsSold}',Icons.shopping_cart),
      stat('Sales',money(store.salesTotal),Icons.payments),
      stat('Profit',money(store.profit),Icons.trending_up),
    ]),
    const SizedBox(height:15),
    Row(children:[
      Expanded(child:FilledButton.icon(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>AddProduct(store))),icon:const Icon(Icons.add),label:const Text('Add Product'))),
      const SizedBox(width:10),
      Expanded(child:FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:green),
        onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>SellPage(store))),icon:const Icon(Icons.sell),label:const Text('Sell')))]),
    const SizedBox(height:18),
    const Text('Business Tools',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),
    Wrap(spacing:8,runSpacing:8,children:[
      tool(c,'Reports',Icons.bar_chart,Reports(store)),
      tool(c,'Low Stock',Icons.warning_amber,LowStock(store)),
      tool(c,'Expiry',Icons.event_busy,ExpiryPage(store)),
      tool(c,'Customers',Icons.people_alt_outlined,SimplePage('Customers')),
      tool(c,'Suppliers',Icons.local_shipping_outlined,SimplePage('Suppliers')),
      tool(c,'Expenses',Icons.receipt_long,SimplePage('Expenses')),
    ]),
    const SizedBox(height:18),
    const Text('Low Stock',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
    ...store.lowStock.take(3).map((p)=>productTile(p)),
  ]));
}

Widget stat(String a,String b,IconData icon)=>Card(elevation:0,child:Padding(padding:const EdgeInsets.all(12),
  child:Row(children:[CircleAvatar(backgroundColor:blue.withOpacity(.1),child:Icon(icon,color:blue,size:19)),
    const SizedBox(width:8),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,
      children:[Text(a,style:const TextStyle(color:Colors.grey,fontSize:12)),Text(b,maxLines:1,overflow:TextOverflow.ellipsis,
        style:const TextStyle(fontWeight:FontWeight.bold))]))])));

Widget tool(BuildContext c,String title,IconData icon,Widget page)=>SizedBox(
  width:108,child:Card(elevation:0,child:InkWell(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>page)),
    borderRadius:BorderRadius.circular(14),child:Padding(padding:const EdgeInsets.symmetric(vertical:14),
      child:Column(children:[Icon(icon,color:blue),const SizedBox(height:5),Text(title,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w600))])))));

Widget productTile(Product p)=>Card(elevation:0,child:ListTile(
  leading:CircleAvatar(backgroundColor:blue.withOpacity(.1),child:const Icon(Icons.inventory_2,color:blue)),
  title:Text(p.name,style:const TextStyle(fontWeight:FontWeight.bold)),
  subtitle:Text('${p.category} • ${p.unit} • Qty: ${p.quantity}'),
  trailing:Text(money(p.sellingPrice),style:const TextStyle(fontWeight:FontWeight.bold))));

class StockPage extends StatefulWidget{
  final KoraStore store; const StockPage(this.store,{super.key});
  @override State<StockPage> createState()=>_StockState();
}
class _StockState extends State<StockPage>{
  String q='',cat='All';
  @override Widget build(BuildContext c){
    final cats=['All',...categories[widget.store.businessType]!.toSet()];
    final list=widget.store.products.where((p)=>p.name.toLowerCase().contains(q.toLowerCase())&&(cat=='All'||p.category==cat)).toList();
    return Scaffold(appBar:AppBar(title:Text('${widget.store.businessType} Stock'),actions:[
      IconButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>AddProduct(widget.store))),icon:const Icon(Icons.add))]),
      body:Column(children:[
        Padding(padding:const EdgeInsets.all(14),child:TextField(onChanged:(v)=>setState(()=>q=v),
          decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search product, SKU or barcode...'))),
        SizedBox(height:43,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:14),
          children:cats.map((x)=>Padding(padding:const EdgeInsets.only(right:7),
            child:ChoiceChip(label:Text(x),selected:cat==x,onSelected:(_)=>setState(()=>cat=x)))).toList())),
        Expanded(child:list.isEmpty?const Center(child:Text('No products found')):ListView.builder(
          padding:const EdgeInsets.all(14),itemCount:list.length,itemBuilder:(_,i)=>productTile(list[i])))
      ]));
  }
}

class AddProduct extends StatefulWidget{
  final KoraStore store; const AddProduct(this.store,{super.key});
  @override State<AddProduct> createState()=>_AddProductState();
}
class _AddProductState extends State<AddProduct>{
  final name=TextEditingController(),buy=TextEditingController(),sell=TextEditingController(),
    qty=TextEditingController(),supplier=TextEditingController(),sku=TextEditingController(),
    barcode=TextEditingController(),brand=TextEditingController(),variant=TextEditingController(),
    batch=TextEditingController(),expiry=TextEditingController();
  late String category; String unit='Piece';
  bool trackExpiry=false,trackSerial=false;

  @override void initState(){super.initState();category=categories[widget.store.businessType]!.first;}
  bool get isPharmacy=>widget.store.businessType=='Pharmacy';
  bool get isPhone=>widget.store.businessType=='Phone Shop'||widget.store.businessType=='Electronics';
  bool get isFashion=>widget.store.businessType=='Boutique';
  bool get isRestaurant=>widget.store.businessType=='Restaurant';

  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Add Product')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      field(name,'Product / Item Name',Icons.inventory_2_outlined),
      const SizedBox(height:11),
      DropdownButtonFormField<String>(value:category,decoration:const InputDecoration(labelText:'Category'),
        items:categories[widget.store.businessType]!.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
        onChanged:(v)=>setState(()=>category=v!)),
      const SizedBox(height:11),
      Row(children:[Expanded(child:field(brand,'Brand',Icons.sell_outlined)),const SizedBox(width:10),
        Expanded(child:field(variant,isFashion?'Size / Colour':'Model / Variant',Icons.tune))]),
      const SizedBox(height:11),
      Row(children:[Expanded(child:field(buy,'Buying Price ₦',Icons.arrow_downward,number:true)),
        const SizedBox(width:10),Expanded(child:field(sell,'Selling Price ₦',Icons.arrow_upward,number:true))]),
      const SizedBox(height:11),
      Row(children:[Expanded(child:field(qty,isRestaurant?'Available Qty':'Quantity',Icons.numbers,number:true)),
        const SizedBox(width:10),Expanded(child:DropdownButtonFormField<String>(value:unit,
          decoration:const InputDecoration(labelText:'Unit'),
          items:['Piece','Pack','Box','Bag','Bottle','Carton','Kg','Litre','Plate','Portion','Pair'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
          onChanged:(v)=>setState(()=>unit=v!)))]),
      const SizedBox(height:11),
      field(supplier,'Supplier',Icons.local_shipping_outlined),
      const SizedBox(height:11),
      Row(children:[Expanded(child:field(sku,'SKU / Item Code',Icons.qr_code_2)),
        const SizedBox(width:10),Expanded(child:field(barcode,'Barcode',Icons.barcode))]),
      if(isPhone) ...[const SizedBox(height:4),SwitchListTile(
        title:const Text('Track serial / IMEI'),subtitle:const Text('Useful for phones and electronics'),
        value:trackSerial,onChanged:(v)=>setState(()=>trackSerial=v))],
      if(isPharmacy) ...[const SizedBox(height:4),SwitchListTile(
        title:const Text('Track expiry & batch'),value:trackExpiry,onChanged:(v)=>setState(()=>trackExpiry=v)),
        if(trackExpiry) Row(children:[Expanded(child:field(batch,'Batch Number',Icons.numbers)),const SizedBox(width:10),
          Expanded(child:field(expiry,'Expiry (e.g. 2027-06)',Icons.event))])],
      if(isRestaurant) const Padding(padding:EdgeInsets.only(top:8),child:Text(
        'Restaurant mode: use items for menu products, ingredients or stock supplies.',
        style:TextStyle(color:Colors.grey))),
      const SizedBox(height:20),
      SizedBox(height:52,child:FilledButton(onPressed:save,child:const Text('Save Product'))),
    ]));

  Widget field(TextEditingController c,String hint,IconData icon,{bool number=false})=>TextField(
    controller:c,keyboardType:number?TextInputType.number:TextInputType.text,
    decoration:InputDecoration(prefixIcon:Icon(icon),hintText:hint));

  Future<void> save()async{
    final b=double.tryParse(buy.text)??0,s=double.tryParse(sell.text)??0,q=int.tryParse(qty.text)??0;
    if(name.text.trim().isEmpty||q<0){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter a product name and quantity.')));return;}
    await widget.store.add(Product(id:DateTime.now().millisecondsSinceEpoch.toString(),name:name.text.trim(),
      category:category,businessType:widget.store.businessType,buyingPrice:b,sellingPrice:s,quantity:q,
      supplier:supplier.text.trim(),sku:sku.text.trim(),unit:unit,barcode:barcode.text.trim(),brand:brand.text.trim(),
      variant:variant.text.trim(),batchNumber:batch.text.trim(),expiryDate:expiry.text.trim(),
      trackExpiry:trackExpiry,trackSerial:trackSerial));
    if(mounted)Navigator.pop(context);
  }
}

class SellPage extends StatefulWidget{
  final KoraStore store; const SellPage(this.store,{super.key});
  @override State<SellPage> createState()=>_SellState();
}
class _SellState extends State<SellPage>{
  Product? p; int qty=1; String payment='Cash';
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Record Sale')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      DropdownButtonFormField<Product>(value:p,decoration:const InputDecoration(labelText:'Select product'),
        items:widget.store.products.map((x)=>DropdownMenuItem(value:x,child:Text('${x.name} — ${x.quantity} left'))).toList(),
        onChanged:(v)=>setState(()=>p=v)),
      if(p!=null)...[
        const SizedBox(height:15),
        Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
          Text(p!.name,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
          Text('Available: ${p!.quantity} ${p!.unit}'),
          Row(mainAxisAlignment:MainAxisAlignment.center,children:[
            IconButton(onPressed:()=>setState(()=>qty=qty>1?qty-1:1),icon:const Icon(Icons.remove_circle_outline)),
            Text('$qty',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
            IconButton(onPressed:()=>setState(()=>qty< p!.quantity?qty+1:qty),icon:const Icon(Icons.add_circle_outline))]),
          Text('Total: ${money(p!.sellingPrice*qty)}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        ]))),
        const SizedBox(height:12),
        DropdownButtonFormField<String>(value:payment,decoration:const InputDecoration(labelText:'Payment Method'),
          items:['Cash','Transfer','POS','Credit'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
          onChanged:(v)=>setState(()=>payment=v!)),
        const SizedBox(height:20),
        SizedBox(height:52,child:FilledButton(onPressed:complete,child:const Text('Complete Sale')))
      ]]));
  Future<void> complete()async{
    if(p==null)return;
    await widget.store.sell(p!,qty,payment);
    if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Sale recorded successfully.')));Navigator.pop(context);}
  }
}

class History extends StatelessWidget{
  final KoraStore store; const History(this.store,{super.key});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Transaction History')),
    body:store.sales.isEmpty?const Center(child:Text('No transactions yet.')):ListView.builder(
      padding:const EdgeInsets.all(14),itemCount:store.sales.length,itemBuilder:(_,i){final s=store.sales[i];
      return Card(elevation:0,child:ListTile(leading:const CircleAvatar(backgroundColor:Color(0xFFE7F7EF),
        child:Icon(Icons.check,color:green)),title:Text('Sale - ${s.productName}',style:const TextStyle(fontWeight:FontWeight.bold)),
        subtitle:Text('${s.quantity} • ${s.payment} • ${s.date.substring(0,16)}'),trailing:Text(money(s.amount),style:const TextStyle(color:green,fontWeight:FontWeight.bold)));}));
}

class Reports extends StatelessWidget{
  final KoraStore store; const Reports(this.store,{super.key});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Business Reports')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      card('Total Sales',money(store.salesTotal),Icons.payments),
      card('Estimated Profit',money(store.profit),Icons.trending_up),
      card('Stock Value',money(store.stockValue),Icons.account_balance_wallet),
      card('Items Sold','${store.itemsSold}',Icons.shopping_cart),
      const SizedBox(height:18),const Text('Sales Summary',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),...store.sales.take(10).map((s)=>ListTile(title:Text(s.productName),subtitle:Text('${s.quantity} • ${s.payment}'),trailing:Text(money(s.amount))))
    ]);
  Widget card(String a,String b,IconData i)=>Card(elevation:0,child:ListTile(leading:CircleAvatar(backgroundColor:blue.withOpacity(.1),child:Icon(i,color:blue)),
    title:Text(a,style:const TextStyle(color:Colors.grey)),trailing:Text(b,style:const TextStyle(fontWeight:FontWeight.bold))));
}

class LowStock extends StatelessWidget{
  final KoraStore store; const LowStock(this.store,{super.key});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Low Stock')),
    body:store.lowStock.isEmpty?const Center(child:Text('No low-stock products.')):ListView(
      padding:const EdgeInsets.all(14),children:store.lowStock.map((p)=>productTile(p)).toList()));
}

class ExpiryPage extends StatelessWidget{
  final KoraStore store; const ExpiryPage(this.store,{super.key});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Expiry & Batch')),
    body:store.expiring.isEmpty?const Center(child:Text('No expiry-tracked items yet.')):ListView(
      padding:const EdgeInsets.all(14),children:store.expiring.map((p)=>Card(child:ListTile(
        leading:const Icon(Icons.event_busy,color:Colors.orange),title:Text(p.name),subtitle:Text('Batch: ${p.batchNumber.isEmpty?'—':p.batchNumber}'),
        trailing:Text(p.expiryDate,style:const TextStyle(fontWeight:FontWeight.bold))))).toList()));
}

class Profile extends StatelessWidget{
  final KoraStore store; const Profile(this.store,{super.key});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Business Profile')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const CircleAvatar(radius:42,backgroundColor:blue,child:Icon(Icons.store,color:Colors.white,size:40)),
      const SizedBox(height:10),Center(child:Text(store.businessName,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold))),
      Center(child:Text(store.businessType,style:const TextStyle(color:Colors.grey))),
      const SizedBox(height:25),
      ListTile(leading:const Icon(Icons.business),title:const Text('Change Business Type'),
        subtitle:Text(store.businessType),onTap:()=>showBusinessSetup(c,store)),
      const ListTile(leading:Icon(Icons.people_outline),title:Text('Staff Management')),
      const ListTile(leading:Icon(Icons.cloud_outlined),title:Text('Backup & Sync'),subtitle:Text('Offline mode in MVP')),
      const ListTile(leading:Icon(Icons.notifications_none),title:Text('Notifications')),
      const ListTile(leading:Icon(Icons.help_outline),title:Text('Help & Support')),
    ]));
}

class SimplePage extends StatelessWidget{
  final String title; const SimplePage(this.title,{super.key});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(title)),
    body:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
      Icon(Icons.construction,color:blue,size:55),const SizedBox(height:12),
      Text('$title module is next',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:5),const Text('The KORA architecture is ready for this module.')]))));
}

extension FirstOrNull<E> on Iterable<E>{E? get firstOrNull=>isEmpty?null:first;}
